---
layout: ProjectsLayout
projects:
    - title: First project
      description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium hic nemo voluptatum.

      link: https://ahmadmostafa.com
      languages:
        - JS
        - Python
        - Rust
    - title: Second project
      description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium hic nemo voluptatum.
      link: https://ahmadmostafa.com
      languages:
        - C++
        - Go
    - title: Third project
      description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium hic nemo voluptatum.
      link: https://ahmadmostafa.com
      languages:
        - Java
        - Python
---
